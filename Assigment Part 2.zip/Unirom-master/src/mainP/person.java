package mainP;


public interface person {
	String getname();
	String gettype();


}
