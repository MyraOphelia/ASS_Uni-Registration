# Part 1

## A. Member Contributions

No | ID         | Name              | Task descriptions                                          | Contribution %
-- | ---------- | ------------------| -----------------                                          | --------------
1  |1231301467  |Intan Nur Habriah  |Lead the overall development of the codes                   |25%
2  |1231302444  |Myra Ophelia Iman  |Gather ideas and contribute to the codes development process|20%                 
3  |1221301132  |Hilman Danish      |video editing                                               |10%
4  |1211103899  |Izzfahmi           |Contribute to the codes                                     |5%


## B. Feature Completion

Mark N for Not completed, P for partially completed, Y for completed. 

No | Feature                                                                         | Completed (N/P/Y)
-- | ------------------------------------------------------------------------------- | ---------------
1  | Admin can create students and lecturers.                                        |Y
2  | Admin can create courses and assign courses courses to lecturers.               |Y
3  | Users can login and the system can recognize their user type.                   |Y
4  | Students can self-register for courses in new trimesters.                       |Y
5  | Lecturers can view all the students in their courses.                           |N
6  | Admin can view all the students and the lecturers for courses.                  |Y


## C. Link to Video Presentation

Upload your video presentation to your Google drive or YouTube, then paste the link below. Give your lab lecturer the permission to view the video.

YouTube: https://youtu.be/dNPLtEt4NcI?si=cF60U4sonqp8sIKV

