# Assigment-1_Java

TCP1201 Objected-Oriented Programming and Data Structures Assignment

# The Code

Main.java

# Video Presentation

YouTube Link -https://youtu.be/dNPLtEt4NcI?si=cF60U4sonqp8sIKV
