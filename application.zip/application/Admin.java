package application;


import java.io.Serializable;

public class Admin extends User implements Serializable {
    public Admin(String username, String password) {
        super(username, password);
    }
    // Add any additional properties or methods specific to Admin
}
