package application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Map;

public class AdminPage extends JFrame {
    private Admin admin;
    private UserManager userManager;
    private CourseManager courseManager;

    public AdminPage(Admin admin, UserManager userManager, CourseManager courseManager) {
        this.admin = admin;
        this.userManager = userManager;
        this.courseManager = courseManager;

        setTitle("Admin Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(600, 400);
        getContentPane().setBackground(new Color(240, 240, 240));

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel titleLabel = new JLabel("Welcome, " + admin.getUsername() + "!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, gbc);

        JButton createStudentButton = new JButton("Create Student");
        createStudentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createUser("Student");
            }
        });
        gbc.gridy++;
        add(createStudentButton, gbc);

        JButton createLecturerButton = new JButton("Create Lecturer");
        createLecturerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createUser("Lecturer");
            }
        });
        gbc.gridy++;
        add(createLecturerButton, gbc);

        JButton createCourseButton = new JButton("Create Course");
        createCourseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createCourse();
            }
        });
        gbc.gridy++;
        add(createCourseButton, gbc);

        JButton assignCourseButton = new JButton("Assign Course to Lecturer");
        assignCourseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                assignCourse();
            }
        });
        gbc.gridy++;
        add(assignCourseButton, gbc);

        JButton viewStudentsAndLecturersButton = new JButton("View Students and Lecturers for Courses");
        viewStudentsAndLecturersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewStudentsAndLecturers();
            }
        });
        gbc.gridy++;
        add(viewStudentsAndLecturersButton, gbc);

        JButton logoutButton = new JButton("Log Out");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logOut();
            }
        });
        gbc.gridy++;
        add(logoutButton, gbc);

        setLocationRelativeTo(null);
        setLookAndFeel();
    }

    private void setLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());

            // Set global font
            Font globalFont = new Font("Arial", Font.PLAIN, 14);
            UIManager.put("Label.font", globalFont);
            UIManager.put("Button.font", globalFont);

            // Set global background color
            UIManager.put("Panel.background", new Color(220, 220, 220));
            UIManager.put("Button.background", new Color(70, 130, 180));
            UIManager.put("Button.foreground", Color.WHITE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createUser(String userType) {
        // Implement user creation logic here
        // You may use dialogs to get user information, e.g., username, password, etc.
        // Create a Student or Lecturer object based on userType
        // Add the created user to the UserManager
    };

    private void createCourse() {
        // Implement course creation logic here
        // You may use dialogs to get course information, e.g., name, credits, etc.
        // Create a Course object and add it to the CourseManager
    };

    private void assignCourse() {
        // Implement course assignment logic here
        // You may use dialogs to get course and lecturer information
        // Assign the selected course to the selected lecturer in the CourseManager
    };

    private void viewStudentsAndLecturers() {
        // Implement logic to display a list of courses and their assigned students and lecturers
        StringBuilder message = new StringBuilder("Courses and Assigned Students/Lecturers:\n");

        Map<String, Course> courses = courseManager.getCourses();
        for (Map.Entry<String, Course> entry : courses.entrySet()) {
            Course course = entry.getValue();
            message.append("Course: ").append(course.getName()).append("\n");
            message.append("Assigned Lecturer: ").append(course.getAssignedLecturer()).append("\n");

            // If there are assigned students, add them to the message
            // You need to modify your Course class to keep track of assigned students
            // or retrieve this information from another source
            // For demonstration, assuming there's a getAssignedStudents method in Course
            if (course.getAssignedStudents() != null && !course.getAssignedStudents().isEmpty()) {
                message.append("Assigned Students: ").append(String.join(", ", course.getAssignedStudents())).append("\n");
            }  else {
                message.append("No students assigned to this course.\n");
            }

            message.append("\n");
        }

        JOptionPane.showMessageDialog(this, message.toString());
    }

    private void logOut() {
        int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Log Out", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            // Close the AdminPage frame
            dispose();

            // Redirect to the LoginApp frame
            new LoginApp(userManager, courseManager).setVisible(true);
        }
    }
}
