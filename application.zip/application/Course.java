package application;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Course implements Serializable {
    private String name;
    private int credits;
    private String assignedLecturer;
    private List<String> assignedStudents;

    public Course(String name, int credits) {
        this.name = name;
        this.credits = credits;
        this.assignedLecturer = null;
        this.assignedStudents = new ArrayList<>();
    }

    // Getters and setters for name, credits, assignedLecturer, and assignedStudents

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public String getAssignedLecturer() {
        return assignedLecturer;
    }

    public void setAssignedLecturer(String assignedLecturer) {
        this.assignedLecturer = assignedLecturer;
    }

    public List<String> getAssignedStudents() {
        return assignedStudents;
    }

    public void setAssignedStudents(List<String> assignedStudents) {
        this.assignedStudents = assignedStudents;
    }

    // Additional methods or properties as needed

    @Override
    public String toString() {
        return "Course{" +
                "name='" + name + '\'' +
                ", credits=" + credits +
                ", assignedLecturer='" + assignedLecturer + '\'' +
                ", assignedStudents=" + assignedStudents +
                '}';
    }
}
