package application;


import java.io.FileInputStream; // Add this import for FileInputStream
import java.io.FileNotFoundException; 
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class CourseManager implements Serializable {
    private Map<String, Course> courses;

    public CourseManager() {
        this.courses = new HashMap<>();
    }

    public void addCourse(Course course) {
        courses.put(course.getName(), course);
    }

    public void assignCourseToLecturer(String courseName, String lecturerUsername) {
        Course course = courses.get(courseName);
        if (course != null) {
            course.setAssignedLecturer(lecturerUsername);
        }
    }

    public Course getCourseByName(String courseName) {
        return courses.get(courseName);
    }

    public void saveCoursesToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(courses);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void loadCoursesFromFile(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            courses = (Map<String, Course>) ois.readObject();
        } catch (FileNotFoundException e) {
            // Handle the case when the file is not found
            System.out.println("File not found. Creating a new course map.");
            courses = new HashMap<>();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data from file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
