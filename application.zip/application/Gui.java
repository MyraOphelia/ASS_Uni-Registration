package application; 

import javax.swing.*;

public class Gui{
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Gui().runGui());
    }

    public interface LoginListener {
        void onLogin(String username, String userType);
    }
    

    public void runGui() {
    
        UserManager userManager = new UserManager();
        CourseManager courseManager = new CourseManager();
        
        userManager.loadUsersFromFile("users.dat");
        courseManager.loadCoursesFromFile("courses.dat");

        
        LoginApp loginApp = new LoginApp(userManager, courseManager);
        // Add a callback for successful student login
        loginApp.setLoginCallback((username, userType) -> {
            if ("Student".equals(userType)) {
                openStudentPage(username);
            }
            else if ("Lecturer".equals(userType)){
                openLecturerPage(username);
            }
            else if ("Admin".equals(userType)) {
            	openAdminPage(username);
            }
        });

        loginApp.setVisible(true);
    }
    
    private void openStudentPage(String username) {
        JFrame studentFrame = new StudentPage(username);
        studentFrame.setVisible(true);
    }

    private void openLecturerPage(String username) {
    	Lecturer lecturer = (Lecturer) userManager.getUser(username);
        JFrame lecturerFrame = new LecturerPage(lecturer);
        lecturerFrame.setVisible(true);
    }
    
    private void openAdminPage(String username) {
        Admin admin = new Admin(username, ""); 
        JFrame adminFrame = new AdminPage(admin, userManager, courseManager);
        adminFrame.setVisible(true);
    }
}
