package application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;


public class LecturerPage extends JFrame {
 private Lecturer lecturer;
 private List<String> assignedCourses;

 public LecturerPage(Lecturer lecturer) {
     this.lecturer = lecturer;
     this.assignedCourses = new ArrayList<>();

     setTitle("Lecturer Page");
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setResizable(false);
     setSize(400, 300);
     getContentPane().setBackground(new Color(240, 240, 240));

     setLayout(new GridBagLayout());
     GridBagConstraints gbc = new GridBagConstraints();
     gbc.gridx = 0;
     gbc.gridy = 0;
     gbc.insets = new Insets(10, 10, 10, 10);

     JLabel titleLabel = new JLabel("Welcome, " + lecturer.getUsername() + "!");
     titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
     add(titleLabel, gbc);

     JButton viewAssignedCoursesButton = new JButton("View Assigned Courses");
     viewAssignedCoursesButton.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             viewAssignedCourses();
         }
     });
     gbc.gridy++;
     add(viewAssignedCoursesButton, gbc);

     JButton logoutButton = new JButton("Log Out");
     logoutButton.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             logOut();
         }
     });
     gbc.gridy++;
     add(logoutButton, gbc);

     setLocationRelativeTo(null);
     setLookAndFeel();
 }

 private void viewAssignedCourses() {
     if (assignedCourses.isEmpty()) {
         JOptionPane.showMessageDialog(this, "You are not assigned to any courses.");
     } else {
         StringBuilder message = new StringBuilder("Assigned Courses:\n");
         for (String course : assignedCourses) {
             message.append(course).append("\n");
         }
         JOptionPane.showMessageDialog(this, message.toString());
     }
 }

 private void logOut() {
     int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Log Out", JOptionPane.YES_NO_OPTION);
     if (option == JOptionPane.YES_OPTION) {
         // Close the LecturerPage frame
         dispose();

         // Redirect to the LoginApp frame
         new LoginApp(new UserManager(), new CourseManager()).setVisible(true);
     }
 }

 private void setLookAndFeel() {
     try {
         UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());

         // Set global font
         Font globalFont = new Font("Arial", Font.PLAIN, 14);
         UIManager.put("Label.font", globalFont);
         UIManager.put("Button.font", globalFont);

         // Set global background color
         UIManager.put("Panel.background", new Color(220, 220, 220));
         UIManager.put("Button.background", new Color(70, 130, 180));
         UIManager.put("Button.foreground", Color.WHITE);
     } catch (Exception e) {
         e.printStackTrace();
     }
 	}
}
