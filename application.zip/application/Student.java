// Student.java
package application;

import java.io.Serializable;

public class Student extends User implements Serializable {
    // You can add specific properties or methods for the Student class
    public Student(String username, String password) {
        super(username, password);
    }
}
